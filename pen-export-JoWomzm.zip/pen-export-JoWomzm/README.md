# Факт Токіо

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Ld10042010/pen/01a0431c-83e5-7838-b8d9-21199640cf7a](https://codepen.io/editor/Ld10042010/pen/01a0431c-83e5-7838-b8d9-21199640cf7a).

